#!/bin/bash
echo "Starting Backend Server..."
cd backend
if [ ! -f "node_modules/.bin/nodemon" ]; then
  echo "Installing dependencies..."
  npm install
fi
echo "Starting server on http://localhost:5000"
npm run dev
