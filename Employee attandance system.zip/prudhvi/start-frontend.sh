#!/bin/bash
echo "Starting Frontend Server..."
cd frontend
if [ ! -f "node_modules/.bin/vite" ]; then
  echo "Installing dependencies..."
  npm install
fi
echo "Starting frontend on http://localhost:5173"
npm run dev
