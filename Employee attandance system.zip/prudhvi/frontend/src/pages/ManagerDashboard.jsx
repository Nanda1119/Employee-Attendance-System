import React, {useState, useEffect} from 'react';
import { api } from '../api';

export default function ManagerDashboard(){
  const [data,setData] = useState([]);
  const token = localStorage.getItem('token');
  const [start,setStart] = useState('');
  const [end,setEnd] = useState('');
  const [empId,setEmpId] = useState('');
  const [loading, setLoading] = useState(false);
  
  async function load(){
    setLoading(true);
    const q = new URLSearchParams();
    if(start) q.set('start', start);
    if(end) q.set('end', end);
    if(empId) q.set('employeeId', empId);
    const apiBase = import.meta.env.VITE_API_URL || import.meta.env.REACT_APP_API_URL || 'http://localhost:5000/api';
    const baseUrl = apiBase.replace('/api', '') || 'http://localhost:5000';
    const res = await fetch(baseUrl + '/api/attendance/all?' + q.toString(), {
      headers: { Authorization: 'Bearer ' + token }
    });
    const json = await res.json();
    if(res.ok) setData(json);
    else alert(json.msg || 'Error');
    setLoading(false);
  }
  useEffect(()=>{ load(); }, []);
  
  async function exportCSV(){
    const apiBase = import.meta.env.VITE_API_URL || import.meta.env.REACT_APP_API_URL || 'http://localhost:5000/api';
    const baseUrl = apiBase.replace('/api', '') || 'http://localhost:5000';
    const res = await fetch(baseUrl + '/api/attendance/export', {
      headers: { Authorization: 'Bearer ' + token }
    });
    if(res.ok){
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = 'attendance.csv'; a.click();
      alert('✅ CSV exported successfully!');
    } else {
      const text = await res.text();
      alert('Export failed: ' + text);
    }
  }
  
  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h2>Manager Dashboard</h2>
        <p style={{color: 'var(--text-secondary)', margin: 0}}>View and manage employee attendance records</p>
      </div>
      
      <div className="filter-bar">
        <div className="filter-group">
          <label>Start Date</label>
          <input type="date" value={start} onChange={e=>setStart(e.target.value)} />
        </div>
        <div className="filter-group">
          <label>End Date</label>
          <input type="date" value={end} onChange={e=>setEnd(e.target.value)} />
        </div>
        <div className="filter-group">
          <label>Employee ID</label>
          <input placeholder="Filter by Employee ID" value={empId} onChange={e=>setEmpId(e.target.value)} />
        </div>
        <div className="filter-actions">
          <button onClick={load} disabled={loading}>
            {loading ? 'Loading...' : '🔍 Filter'}
          </button>
          <button onClick={exportCSV} className="btn-secondary">📥 Export CSV</button>
        </div>
      </div>
      
      <div className="table-container">
        {data.length > 0 ? (
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Name</th>
                <th>Email</th>
                <th>Employee ID</th>
                <th>Check In</th>
                <th>Check Out</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {data.map(a => (
                <tr key={a._id}>
                  <td>{a.date}</td>
                  <td>{a.user?.name || '-'}</td>
                  <td>{a.user?.email || '-'}</td>
                  <td>{a.user?.employeeId || '-'}</td>
                  <td>{a.checkInTime ? new Date(a.checkInTime).toLocaleString() : '-'}</td>
                  <td>{a.checkOutTime ? new Date(a.checkOutTime).toLocaleString() : '-'}</td>
                  <td>
                    <span style={{
                      padding: '0.25rem 0.75rem',
                      borderRadius: '12px',
                      fontSize: '0.875rem',
                      fontWeight: '500',
                      backgroundColor: a.status === 'present' ? '#d1fae5' : a.status === 'absent' ? '#fee2e2' : '#fef3c7',
                      color: a.status === 'present' ? '#065f46' : a.status === 'absent' ? '#991b1b' : '#92400e'
                    }}>
                      {a.status || '-'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="empty-state">
            <p>No attendance records found. Try adjusting your filters.</p>
          </div>
        )}
      </div>
    </div>
  )
}

