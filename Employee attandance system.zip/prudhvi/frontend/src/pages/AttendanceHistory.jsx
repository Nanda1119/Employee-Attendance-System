import React, {useEffect, useState} from 'react';
import { api } from '../api';
import { useNavigate } from 'react-router-dom';

export default function AttendanceHistory(){
  const [list,setList] = useState([]);
  const [loading, setLoading] = useState(true);
  const token = localStorage.getItem('token');
  const nav = useNavigate();
  
  useEffect(()=>{ load(); }, []);
  
  async function load(){
    setLoading(true);
    const res = await api('/attendance/my-history','GET', null, token);
    if(res.ok) setList(res.data);
    setLoading(false);
  }
  
  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h2>My Attendance History</h2>
        <p style={{color: 'var(--text-secondary)', margin: 0}}>View your complete attendance records</p>
      </div>
      
      <div className="table-container">
        {loading ? (
          <div className="empty-state">
            <p>Loading...</p>
          </div>
        ) : list.length > 0 ? (
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Check In</th>
                <th>Check Out</th>
                <th>Status</th>
                <th>Total Hours</th>
              </tr>
            </thead>
            <tbody>
              {list.map(it=>(
                <tr key={it._id}>
                  <td>{it.date}</td>
                  <td>{it.checkInTime ? new Date(it.checkInTime).toLocaleString() : '-'}</td>
                  <td>{it.checkOutTime ? new Date(it.checkOutTime).toLocaleString() : '-'}</td>
                  <td>
                    <span style={{
                      padding: '0.25rem 0.75rem',
                      borderRadius: '12px',
                      fontSize: '0.875rem',
                      fontWeight: '500',
                      backgroundColor: it.status === 'present' ? '#d1fae5' : it.status === 'absent' ? '#fee2e2' : '#fef3c7',
                      color: it.status === 'present' ? '#065f46' : it.status === 'absent' ? '#991b1b' : '#92400e'
                    }}>
                      {it.status || '-'}
                    </span>
                  </td>
                  <td>{it.totalHours ? it.totalHours.toFixed(2) + ' hrs' : '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="empty-state">
            <h4>No attendance records found</h4>
            <p>Your attendance history will appear here once you start checking in.</p>
            <button onClick={() => nav('/employee')} style={{marginTop: '1rem'}}>Go to Dashboard</button>
          </div>
        )}
      </div>
    </div>
  );
}

