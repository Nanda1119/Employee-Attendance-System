import React, {useState} from 'react';
import { api } from '../api';
import { useNavigate } from 'react-router-dom';

export default function Login(){
  const [email,setEmail] = useState('');
  const [password,setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const nav = useNavigate();
  
  async function submit(e){
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await api('/auth/login','POST',{ email, password });
      if(res.ok){
        localStorage.setItem('token', res.data.token);
        localStorage.setItem('user', JSON.stringify(res.data.user));
        if(res.data.user.role === 'manager') nav('/manager'); else nav('/employee');
      } else {
        setError(res.data?.msg || 'Login failed. Please check your credentials.');
      }
    } catch(err) {
      setError('Unable to connect to server. Please make sure the backend server is running on http://localhost:5000');
    } finally {
      setLoading(false);
    }
  }
  return (
    <div className="form-container">
      <form onSubmit={submit}>
        <h2>Login</h2>
        {error && (
          <div style={{
            padding: '0.75rem',
            marginBottom: '1rem',
            backgroundColor: '#fee2e2',
            color: '#991b1b',
            borderRadius: '8px',
            fontSize: '0.875rem'
          }}>
            {error}
          </div>
        )}
        <div className="form-group">
          <input 
            placeholder="Email" 
            type="email"
            value={email} 
            onChange={e=>setEmail(e.target.value)} 
            required
            disabled={loading}
          />
        </div>
        <div className="form-group">
          <input 
            placeholder="Password" 
            type="password" 
            value={password} 
            onChange={e=>setPassword(e.target.value)} 
            required
            disabled={loading}
          />
        </div>
        <div className="form-actions">
          <button type="submit" style={{width: '100%'}} disabled={loading}>
            {loading ? 'Logging in...' : 'Login'}
          </button>
        </div>
      </form>
    </div>
  );
}

