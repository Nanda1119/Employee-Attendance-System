import React, {useState, useEffect} from 'react';
import { api } from '../api';
import { useNavigate } from 'react-router-dom';

export default function EmployeeDashboard(){
  const [status, setStatus] = useState(null);
  const token = localStorage.getItem('token');
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  const nav = useNavigate();

  async function checkIn(){
    const res = await api('/attendance/checkin','POST', null, token);
    if(res.ok) alert('✅ Checked in successfully!'); else alert(res.data.msg || 'Error');
    loadStatus();
  }
  async function checkOut(){
    const res = await api('/attendance/checkout','POST', null, token);
    if(res.ok) alert('✅ Checked out successfully!'); else alert(res.data.msg || 'Error');
    loadStatus();
  }
  async function loadStatus(){
    const res = await api('/attendance/my-history','GET', null, token);
    if(res.ok) setStatus(res.data[0] || null);
  }
  useEffect(()=>{ loadStatus(); }, []);
  
  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h2>Employee Dashboard</h2>
        <p style={{color: 'var(--text-secondary)', margin: 0}}>Welcome, {user.name}</p>
      </div>
      
      <div className="dashboard-actions">
        <button onClick={checkIn} className="btn-secondary">🕐 Check In</button>
        <button onClick={checkOut} className="btn-danger">🕐 Check Out</button>
        <button onClick={()=>nav('/history')}>📊 My History</button>
      </div>

      {status ? (
        <div className="status-card">
          <h4>Today's Attendance Status</h4>
          <div className="status-info">
            <div className="status-item">
              <strong>Date</strong>
              <span>{status.date}</span>
            </div>
            <div className="status-item">
              <strong>Check In</strong>
              <span>{status.checkInTime ? new Date(status.checkInTime).toLocaleTimeString() : 'Not checked in'}</span>
            </div>
            <div className="status-item">
              <strong>Check Out</strong>
              <span>{status.checkOutTime ? new Date(status.checkOutTime).toLocaleTimeString() : 'Not checked out'}</span>
            </div>
            <div className="status-item">
              <strong>Total Hours</strong>
              <span>{status.totalHours ? status.totalHours.toFixed(2) + ' hrs' : '-'}</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="card">
          <div className="empty-state">
            <h4>No attendance record for today</h4>
            <p>Click "Check In" to start tracking your attendance</p>
          </div>
        </div>
      )}
    </div>
  );
}

