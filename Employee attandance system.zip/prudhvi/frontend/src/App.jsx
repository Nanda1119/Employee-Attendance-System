import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import EmployeeDashboard from './pages/EmployeeDashboard.jsx';
import ManagerDashboard from './pages/ManagerDashboard.jsx';
import AttendanceHistory from './pages/AttendanceHistory.jsx';
import PrivateRoute from './components/PrivateRoute.jsx';
import './App.css';

function App(){
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  const isAuthenticated = !!localStorage.getItem('token');
  
  return (
    <BrowserRouter>
      <nav>
        <div className="container" style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between'}}>
          <div>
            <Link to="/" style={{fontSize: '1.25rem', fontWeight: '600', color: 'var(--primary)'}}>📊 Attendance System</Link>
          </div>
          <div>
            {!isAuthenticated ? (
              <>
                <Link to="/login">Login</Link>
                <Link to="/register">Register</Link>
              </>
            ) : (
              <>
                {user.role === 'manager' ? (
                  <Link to="/manager">Dashboard</Link>
                ) : (
                  <>
                    <Link to="/employee">Dashboard</Link>
                    <Link to="/history">History</Link>
                  </>
                )}
                <Link to="/" onClick={() => {
                  localStorage.removeItem('token');
                  localStorage.removeItem('user');
                  window.location.href = '/';
                }}>Logout</Link>
              </>
            )}
          </div>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={
          <div className="welcome-page">
            <div className="container">
              <h1>Welcome to Attendance System</h1>
              <p>Track your work hours efficiently and manage attendance records</p>
              <div className="welcome-actions">
                <Link to="/login"><button>Login</button></Link>
                <Link to="/register"><button className="btn-outline">Register</button></Link>
              </div>
            </div>
          </div>
        } />
        <Route path="/login" element={<Login/>} />
        <Route path="/register" element={<Register/>} />
        <Route path="/employee" element={<PrivateRoute><EmployeeDashboard/></PrivateRoute>} />
        <Route path="/history" element={<PrivateRoute><AttendanceHistory/></PrivateRoute>} />
        <Route path="/manager" element={<PrivateRoute><ManagerDashboard/></PrivateRoute>} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
