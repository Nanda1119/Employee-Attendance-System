const API_URL = import.meta.env.VITE_API_URL || import.meta.env.REACT_APP_API_URL || 'http://localhost:5000/api';

export async function api(path, method='GET', body=null, token=null){
  try {
    const headers = { 'Content-Type': 'application/json' };
    if(token) headers['Authorization'] = 'Bearer ' + token;
    
    const url = API_URL + path;
    console.log(`[API] ${method} ${url}`, body ? { body } : '');
    
    const res = await fetch(url, {
      method,
      headers,
      body: body ? JSON.stringify(body) : null
    });
    
    const text = await res.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch(e) {
      data = { msg: text || 'An error occurred' };
    }
    
    console.log(`[API] Response:`, { status: res.status, ok: res.ok, data });
    
    return { ok: res.ok, data, status: res.status };
  } catch(error) {
    console.error('[API] Network Error:', error);
    console.error('[API] Make sure the backend server is running on http://localhost:5000');
    return { 
      ok: false, 
      data: { msg: error.message || 'Network error. Please check if the server is running on http://localhost:5000' },
      status: 0
    };
  }
}
