# Employee Attendance System

A complete full-stack Employee Attendance System with backend (Node.js + Express + MongoDB) and frontend (React).

## Features

- **Authentication**: Employee and Manager roles with JWT-based auth
- **Check-in/Check-out**: Employees can check in and check out
- **Attendance History**: View personal attendance records
- **Manager Dashboard**: View all employees' attendance with filters
- **CSV Export**: Managers can export attendance data to CSV

## Project Structure

```
attendance-system/
├─ backend/
│  ├─ package.json
│  ├─ server.js
│  ├─ config/
│  │  └─ db.js
│  ├─ models/
│  │  ├─ User.js
│  │  └─ Attendance.js
│  ├─ routes/
│  │  ├─ auth.js
│  │  └─ attendance.js
│  ├─ middleware/
│  │  └─ auth.js
│  └─ seed.js
├─ frontend/
│  ├─ package.json
│  ├─ public/
│  └─ src/
│     ├─ index.js
│     ├─ App.jsx
│     ├─ api.js
│     ├─ pages/
│     │  ├─ Login.jsx
│     │  ├─ Register.jsx
│     │  ├─ EmployeeDashboard.jsx
│     │  ├─ AttendanceHistory.jsx
│     │  └─ ManagerDashboard.jsx
│     └─ components/
│        └─ PrivateRoute.jsx
└─ README.md
```

## Prerequisites

- Node.js (v18+ recommended)
- npm
- MongoDB (local installation or MongoDB Atlas connection string)

## Setup Instructions

### 1. Backend Setup

```bash
cd backend
npm install
```

Create a `.env` file in the `backend` directory:

```env
MONGO_URI=mongodb://localhost:27017/attendance
JWT_SECRET=your_jwt_secret_here
PORT=5000
```

**For MongoDB Atlas**, use:
```env
MONGO_URI=mongodb+srv://username:password@cluster.mongodb.net/attendance
```

### 2. Seed Database (Optional)

```bash
npm run seed
```

This creates:
- Manager: `manager@example.com` / `manager123`
- Employees: `alice@example.com` / `employee123`, `bob@example.com` / `employee123`

### 3. Start Backend Server

```bash
npm run dev    # runs with nodemon
# or
npm start      # runs with node
```

Server runs on `http://localhost:5000` by default.

### 4. Frontend Setup

```bash
cd ../frontend
npm install
```

Create a `.env` file in the `frontend` directory (optional):

```env
VITE_API_URL=http://localhost:5000/api
```

**Note**: Since this project uses Vite, use `VITE_API_URL` (not `REACT_APP_API_URL`). The code supports both for compatibility.

### 5. Start Frontend

```bash
npm run dev    # for Vite
```

Open `http://localhost:3000` (or the port shown in terminal).

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login
- `GET /api/auth/me` - Get current user (requires auth)

### Attendance
- `POST /api/attendance/checkin` - Check in (employee, requires auth)
- `POST /api/attendance/checkout` - Check out (employee, requires auth)
- `GET /api/attendance/my-history` - Get personal attendance history (employee, requires auth)
- `GET /api/attendance/all?start=YYYY-MM-DD&end=YYYY-MM-DD&employeeId=E001` - Get all attendance (manager, requires auth)
- `GET /api/attendance/export` - Export CSV (manager, requires auth)

## Test Accounts

After running seed:
- **Manager**: `manager@example.com` / `manager123`
- **Employee 1**: `alice@example.com` / `employee123`
- **Employee 2**: `bob@example.com` / `employee123`

## Usage

1. Register a new account or login with seeded accounts
2. **As Employee**:
   - Check in when you arrive
   - Check out when you leave
   - View your attendance history
3. **As Manager**:
   - View all employees' attendance
   - Filter by date range or employee ID
   - Export attendance data to CSV

## Technologies Used

### Backend
- Node.js
- Express.js
- MongoDB with Mongoose
- JWT for authentication
- bcryptjs for password hashing
- csv-writer for CSV export
- moment.js for date handling

### Frontend
- React
- React Router DOM
- Vite (build tool)

## Notes & Next Steps

- Add form validation and better error handling
- Implement calendar view for attendance history
- Add color coding for present/absent/late/half-day statuses
- Enhance UI with modern CSS framework (Tailwind, Material UI)
- Add unit and integration tests
- Configure for production deployment

## License

MIT

