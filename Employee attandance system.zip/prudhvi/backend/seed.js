require('dotenv').config();
const connectDB = require('./config/db');
const User = require('./models/User');
const Attendance = require('./models/Attendance');
const bcrypt = require('bcryptjs');
(async function(){
  try{
    await connectDB(process.env.MONGO_URI);
    await User.deleteMany({});
    await Attendance.deleteMany({});
    const salt = await bcrypt.genSalt(10);
    const mPass = await bcrypt.hash('manager123', salt);
    const ePass = await bcrypt.hash('employee123', salt);
    const manager = await User.create({ name:'Manager One', email:'manager@example.com', password:mPass, role:'manager', employeeId:'M001' });
    const emp1 = await User.create({ name:'Alice', email:'alice@example.com', password:ePass, role:'employee', employeeId:'E001' });
    const emp2 = await User.create({ name:'Bob', email:'bob@example.com', password:ePass, role:'employee', employeeId:'E002' });

    const today = (new Date()).toISOString().slice(0,10);
    await Attendance.create({ user: emp1._id, date: today, checkInTime: new Date(), status: 'present' });
    console.log('Seeded');
    process.exit(0);
  }catch(err){ console.error(err); process.exit(1); }
})();

