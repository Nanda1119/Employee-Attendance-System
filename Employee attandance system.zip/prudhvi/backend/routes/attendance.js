const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Attendance = require('../models/Attendance');
const User = require('../models/User');
const { createObjectCsvWriter } = require('csv-writer');
const moment = require('moment');

// employee checkin
router.post('/checkin', auth, async (req,res)=>{
  try{
    const user = req.user;
    const date = moment().format('YYYY-MM-DD');
    let att = await Attendance.findOne({ user: user._id, date });
    const now = new Date();
    if(att) {
      // already exists, maybe checkin done
      if(att.checkInTime) return res.status(400).json({ msg:'Already checked in' });
      att.checkInTime = now;
      await att.save();
      return res.json(att);
    } else {
      att = new Attendance({ user: user._id, date, checkInTime: now, status: 'present' });
      await att.save();
      return res.json(att);
    }
  }catch(err){
    res.status(500).json({ msg:'Server error' });
  }
});

// employee checkout
router.post('/checkout', auth, async (req,res)=>{
  try{
    const user = req.user;
    const date = moment().format('YYYY-MM-DD');
    const att = await Attendance.findOne({ user: user._id, date });
    if(!att) return res.status(400).json({ msg:'No check-in found' });
    if(att.checkOutTime) return res.status(400).json({ msg:'Already checked out' });
    att.checkOutTime = new Date();
    if(att.checkInTime){
      att.totalHours = (att.checkOutTime - att.checkInTime) / (1000*60*60);
    }
    await att.save();
    res.json(att);
  }catch(err){
    res.status(500).json({ msg:'Server error' });
  }
});

// my history
router.get('/my-history', auth, async (req,res)=>{
  try{
    const ats = await Attendance.find({ user: req.user._id }).sort({ date: -1 });
    res.json(ats);
  }catch(err){ res.status(500).json({ msg:'Server error' }); }
});

// manager: all employees attendance (with optional filters)
router.get('/all', auth, async (req,res)=>{
  try{
    if(req.user.role !== 'manager') return res.status(403).json({ msg:'Forbidden' });
    const { start, end, employeeId } = req.query;
    const q = {};
    if(start && end) q.date = { $gte: start, $lte: end };
    if(employeeId) {
      const user = await User.findOne({ employeeId });
      if(user) q.user = user._id;
    }
    const ats = await Attendance.find(q).populate('user','name email employeeId').sort({ date:-1 });
    res.json(ats);
  }catch(err){ res.status(500).json({ msg:'Server error' }); }
});

// manager: export CSV
router.get('/export', auth, async (req,res)=>{
  try{
    if(req.user.role !== 'manager') return res.status(403).json({ msg:'Forbidden' });
    const ats = await Attendance.find().populate('user','name email employeeId').sort({ date: -1 });
    const csvWriter = createObjectCsvWriter({
      path: '/tmp/attendance_export.csv',
      header: [
        {id:'date', title:'Date'},
        {id:'name', title:'Name'},
        {id:'email', title:'Email'},
        {id:'employeeId', title:'EmployeeId'},
        {id:'checkIn', title:'CheckIn'},
        {id:'checkOut', title:'CheckOut'},
        {id:'status', title:'Status'},
        {id:'hours', title:'TotalHours'}
      ]
    });
    const records = ats.map(a => ({
      date: a.date,
      name: a.user?.name || '',
      email: a.user?.email || '',
      employeeId: a.user?.employeeId || '',
      checkIn: a.checkInTime ? a.checkInTime.toISOString() : '',
      checkOut: a.checkOutTime ? a.checkOutTime.toISOString() : '',
      status: a.status,
      hours: a.totalHours?.toFixed(2) || ''
    }));
    await csvWriter.writeRecords(records);
    res.download('/tmp/attendance_export.csv', 'attendance.csv');
  }catch(err){ console.error(err); res.status(500).json({ msg:'Server error' }); }
});

module.exports = router;

